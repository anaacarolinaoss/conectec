package com.example.conectec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
