import 'package:conectec/aluno.dart';
import 'package:flutter/material.dart';

class Admin extends StatelessWidget {
  final _nomeController = TextEditingController();
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();

  void _signup() {
    final nome = _nomeController.text;
    final email = _emailController.text;
    final senha = _senhaController.text;


   
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(title: Text('Cadastro de Administrador')),
      body: Padding(
        
        padding: EdgeInsets.only(top:16.0, right: 500, left: 500),
        
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text("CADASTRE-SE",
            style: TextStyle (fontSize: 40) ,),
            TextField(
              controller: _nomeController,
              decoration: InputDecoration(labelText: 'Nome Completo: '),
            ),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _senhaController,
              decoration: InputDecoration(labelText: 'Senha'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _signup,
              child: Text('Cadastrar'),
            ),
          ],
        ),
      ),
    );
  }
}
