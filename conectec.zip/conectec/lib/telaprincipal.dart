import 'package:conectec/adm.dart';
import 'package:conectec/aluno.dart';
import 'package:flutter/material.dart';

class TelaPrincipal extends StatelessWidget {
  const TelaPrincipal({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'CONECTEC',
          style: TextStyle(color: Color.fromARGB(255, 255, 255, 255)),
        ),
        backgroundColor: Color.fromARGB(255, 126, 28, 24),
      ),
      body: Container(
        color: Color.fromARGB(255, 28, 33, 37),
        padding: const EdgeInsets.all(32),
        width: double.infinity,
        height: double.infinity,
        child: Center(
          
          child: Padding(
            padding: const EdgeInsets.only(top: 200),
            child: Column(
              children: [
                Text(
                  "SEJA BEM VINDO!",
                  style: TextStyle(fontSize: 50,
                   color: Color.fromARGB(255, 255, 254, 254),

                  
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  style: ButtonStyle(minimumSize: MaterialStateProperty.all(Size(500,40))
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Admin()),
                    );
                  },
                  child: const Text(
                    'Cadastrar como Administrador',
                    style: 
                    TextStyle(fontSize: 25,
                  
                color: Color.fromARGB(255, 0, 0, 0),),
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  style: ButtonStyle(minimumSize: MaterialStateProperty.all(Size(500,40))
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => User(
                                email: '',
                              )),
                    );
                  },
                  child: const Text(
                    'Cadastrar como Usuário',
                    style:
                     TextStyle(fontSize: 25,
                  color: Color.fromARGB(255, 0, 0, 0)),
                  ),
                ),
                SizedBox(height: 10,),
    Text('Já tem uma conta?',
    style: TextStyle(fontSize: 20,
                   color: Color.fromARGB(255, 255, 254, 254),

                  
                  ),),
    
    TextButton(
      onPressed: () {
        // Navigate to login page
      },
      child: Text('Entre aqui'),
      style: TextButton.styleFrom(
        primary: Colors.blue, // or any other color
        textStyle: TextStyle(
          decoration: TextDecoration.underline,
        ),
      ),
    ),
      
      
  
              ],
            ),
          ),
        ),
      ),
    );
  }
}
